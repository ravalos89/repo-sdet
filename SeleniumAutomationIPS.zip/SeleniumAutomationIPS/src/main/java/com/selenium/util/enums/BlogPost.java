package com.selenium.util.enums;

public enum BlogPost {
	CARD, IMAGE, PROFILE_PIC, NAME, POSITION, TAG, TITLE, DATE, TEXT
}
