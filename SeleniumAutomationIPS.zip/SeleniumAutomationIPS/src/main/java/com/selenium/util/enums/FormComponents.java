package com.selenium.util.enums;

public enum FormComponents {
	NAME, COMPANY, EMAIL, PHONE, MESSAGE, BUTTON, CHECKBOX
}
