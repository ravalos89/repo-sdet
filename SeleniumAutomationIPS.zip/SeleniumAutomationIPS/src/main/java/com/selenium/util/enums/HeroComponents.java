package com.selenium.util.enums;

public enum HeroComponents {
	TAG, HEADER, TEXT, BTN,

}
