package com.selenium.util.enums;

public enum FirstCardFormatComponents {
	CARD, HEADER, TEXT, MORE_DETAILS_BUTTON, IMAGE_SOURCE, INTEGRATIONS, OUR_EXPERIENCE, CLOSE_DETAILS_BUTTON
}
