package com.selenium.util.enums;

public enum CardWIthIcon {
	CARD, HEADER, TEXT, ICON, IMAGE

}
