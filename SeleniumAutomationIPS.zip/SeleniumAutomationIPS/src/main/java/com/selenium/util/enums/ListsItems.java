package com.selenium.util.enums;

public enum ListsItems {
	FIRST, SECOND, THIRD, FOURTH, FIFTH, SIXTH
}
