package com.selenium.util.enums;

public enum ModuleComponents {

	Header, brandingFront, UXFrontCard, productDesignFrontCard, strategicDesignFrontCard, usabilityTestingFrontCard,
	brandingBackCard, UXBackCard, productDesignBackCard, strategicDesignBackCard, usabilityTestingBackCard, btnNext,
	tagHero, textHero, btnHero, headerHero, headerCard, imgCard, textCard, btnCard, card

}
