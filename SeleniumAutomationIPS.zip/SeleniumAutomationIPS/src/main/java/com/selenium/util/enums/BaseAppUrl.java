package com.selenium.util.enums;

public interface BaseAppUrl {

}
