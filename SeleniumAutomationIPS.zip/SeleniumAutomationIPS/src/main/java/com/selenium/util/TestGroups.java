package com.selenium.util;

public class TestGroups {

	public static final String COMPUTERS = "ComputersApp";
	public static final String IMPLEMENTED = "Implemented";
	public static final String IPSWEBSITE = "IPSWebsite";
	public static final String IPSCENTRAL = "IPSCentral";
	public static final String CHRONOS = "Chronos";
	public static final String ACUITY = "Acuity";
	public static String APP_URL_APPLICANT_SUMMARY="APP_URL_APPLICANT_SUMMARY";
}
