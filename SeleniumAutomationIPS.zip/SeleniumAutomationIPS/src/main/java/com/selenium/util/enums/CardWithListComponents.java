package com.selenium.util.enums;

public enum CardWithListComponents {
	CARD, HEADER, TEXT, IMAGE, MORE_DETAILS_BUTTON, VIDEO_BUTTON
}
